# Medical Chatbot API - Mobile Integration Guide

## API Base URL

```
Development: http://127.0.0.1:8000
Production: [YOUR_PRODUCTION_URL]
```

---

## 📍 Endpoints

### POST `/ask`

Ask a medical question to the chatbot.

**Request Body:**

```json
{
  "question": "What are the symptoms of diabetes?",
  "debug": false // optional, default: false
}
```

**Response:**

```json
{
  "intent": "symptoms",
  "answer": "Common symptoms of diabetes include increased thirst, frequent urination, fatigue, and blurred vision. [1] [2]",
  "sources": [
    {
      "id": 1,
      "text": "Increased thirst and frequent urination are common early signs..."
    },
    {
      "id": 2,
      "text": "Other symptoms may include fatigue, blurred vision..."
    }
  ],
  "debug": null // only present if debug=true in request
}
```

**Possible Intent Values:**

- `causes`
- `definition`
- `other`
- `prevention`
- `risks`
- `symptoms`
- `treatment`

---

## 📱 Code Examples

### React Native / TypeScript

```typescript
// api.ts
const API_BASE_URL = "http://127.0.0.1:8000"; // Change to your production URL

interface QuestionRequest {
  question: string;
  debug?: boolean;
}

interface Source {
  id: number;
  text: string;
}

interface AnswerResponse {
  intent: string;
  answer: string;
  sources: Source[];
  debug?: any;
}

export async function askMedicalQuestion(
  question: string,
  debug: boolean = false
): Promise<AnswerResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/ask`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        question,
        debug,
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data: AnswerResponse = await response.json();
    return data;
  } catch (error) {
    console.error("Error asking medical question:", error);
    throw error;
  }
}

// Usage in component
import { askMedicalQuestion } from "./api";

const handleAskQuestion = async () => {
  try {
    const result = await askMedicalQuestion("What causes high blood pressure?");
    console.log("Intent:", result.intent);
    console.log("Answer:", result.answer);
    console.log("Sources:", result.sources);
  } catch (error) {
    console.error("Failed to get answer:", error);
  }
};
```

---

### Swift (iOS)

```swift
// APIService.swift
import Foundation

struct QuestionRequest: Codable {
    let question: String
    let debug: Bool?
}

struct Source: Codable {
    let id: Int
    let text: String
}

struct AnswerResponse: Codable {
    let intent: String
    let answer: String
    let sources: [Source]
    let debug: [String: Any]?
}

class MedicalChatbotAPI {
    private let baseURL = "http://127.0.0.1:8000" // Change to your production URL

    func askQuestion(_ question: String, debug: Bool = false) async throws -> AnswerResponse {
        guard let url = URL(string: "\(baseURL)/ask") else {
            throw APIError.invalidURL
        }

        let requestBody = QuestionRequest(question: question, debug: debug)
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(requestBody)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse,
              httpResponse.statusCode == 200 else {
            throw APIError.invalidResponse
        }

        let decoder = JSONDecoder()
        return try decoder.decode(AnswerResponse.self, from: data)
    }
}

enum APIError: Error {
    case invalidURL
    case invalidResponse
    case decodingError
}

// Usage in ViewController
let api = MedicalChatbotAPI()

Task {
    do {
        let response = try await api.askQuestion("What are the symptoms of diabetes?")
        print("Intent: \(response.intent)")
        print("Answer: \(response.answer)")
        print("Sources: \(response.sources)")
    } catch {
        print("Error: \(error)")
    }
}
```

---

### Kotlin (Android)

```kotlin
// APIService.kt
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST

data class QuestionRequest(
    val question: String,
    val debug: Boolean = false
)

data class Source(
    val id: Int,
    val text: String
)

data class AnswerResponse(
    val intent: String,
    val answer: String,
    val sources: List<Source>,
    val debug: Map<String, Any>? = null
)

interface MedicalChatbotAPI {
    @POST("ask")
    suspend fun askQuestion(@Body request: QuestionRequest): AnswerResponse

    companion object {
        private const val BASE_URL = "http://127.0.0.1:8000/" // Change to your production URL

        fun create(): MedicalChatbotAPI {
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return retrofit.create(MedicalChatbotAPI::class.java)
        }
    }
}

// Usage in ViewModel or Activity
class MainViewModel : ViewModel() {
    private val api = MedicalChatbotAPI.create()

    fun askQuestion(question: String) {
        viewModelScope.launch {
            try {
                val response = api.askQuestion(QuestionRequest(question = question))
                // Handle response
                println("Intent: ${response.intent}")
                println("Answer: ${response.answer}")
                println("Sources: ${response.sources}")
            } catch (e: Exception) {
                // Handle error
                println("Error: ${e.message}")
            }
        }
    }
}
```

**Add to `build.gradle.kts`:**

```kotlin
dependencies {
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
}
```

---

### Flutter / Dart

```dart
// api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;

class QuestionRequest {
  final String question;
  final bool debug;

  QuestionRequest({required this.question, this.debug = false});

  Map<String, dynamic> toJson() {
    return {
      'question': question,
      'debug': debug,
    };
  }
}

class Source {
  final int id;
  final String text;

  Source({required this.id, required this.text});

  factory Source.fromJson(Map<String, dynamic> json) {
    return Source(
      id: json['id'],
      text: json['text'],
    );
  }
}

class AnswerResponse {
  final String intent;
  final String answer;
  final List<Source> sources;
  final Map<String, dynamic>? debug;

  AnswerResponse({
    required this.intent,
    required this.answer,
    required this.sources,
    this.debug,
  });

  factory AnswerResponse.fromJson(Map<String, dynamic> json) {
    return AnswerResponse(
      intent: json['intent'],
      answer: json['answer'],
      sources: (json['sources'] as List)
          .map((source) => Source.fromJson(source))
          .toList(),
      debug: json['debug'],
    );
  }
}

class MedicalChatbotAPI {
  static const String baseURL = 'http://127.0.0.1:8000'; // Change to your production URL

  Future<AnswerResponse> askQuestion(String question, {bool debug = false}) async {
    final url = Uri.parse('$baseURL/ask');

    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(QuestionRequest(question: question, debug: debug).toJson()),
    );

    if (response.statusCode == 200) {
      return AnswerResponse.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed to load answer: ${response.statusCode}');
    }
  }
}

// Usage in Widget
final api = MedicalChatbotAPI();

Future<void> handleAskQuestion() async {
  try {
    final response = await api.askQuestion('What are the symptoms of diabetes?');
    print('Intent: ${response.intent}');
    print('Answer: ${response.answer}');
    print('Sources: ${response.sources}');
  } catch (e) {
    print('Error: $e');
  }
}
```

**Add to `pubspec.yaml`:**

```yaml
dependencies:
  http: ^1.1.0
```

---

## 🔧 Configuration

### Update Base URL

Replace `http://127.0.0.1:8000` with your production API URL when deploying.

### Error Handling

Always implement proper error handling for:

- Network failures
- Timeout errors
- Invalid responses
- Server errors (500, 503, etc.)

### Loading States

Show loading indicators while waiting for API responses.

### Timeout Settings

Set appropriate timeouts (recommended: 30-60 seconds) as the API may take time to process questions.

---

## 📝 Response Format Details

### Success Response

```json
{
  "intent": "symptoms",
  "answer": "The answer text with citations [1], [2]...",
  "sources": [
    {
      "id": 1,
      "text": "Source text 1"
    },
    {
      "id": 2,
      "text": "Source text 2"
    }
  ]
}
```

### Debug Mode Response (when `debug: true`)

```json
{
  "intent": "symptoms",
  "answer": "The answer text...",
  "sources": [...],
  "debug": {
    "predicted_intent": "symptoms",
    "retrieved_answers_raw": ["raw answer 1", "raw answer 2"],
    "llm_prompt": "Full prompt sent to LLM...",
    "num_retrieved_docs": 3,
    "kb_used": "symptoms_kb.csv"
  }
}
```

---

## 🚨 Error Responses

### 422 Validation Error

```json
{
  "detail": [
    {
      "loc": ["body", "question"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

### 500 Server Error

```json
{
  "detail": "Internal server error"
}
```

---

## 🔐 Security Notes

1. **HTTPS**: Always use HTTPS in production
2. **API Keys**: Don't expose API keys in client-side code
3. **Input Validation**: Validate user input before sending
4. **Rate Limiting**: Implement client-side rate limiting if needed

---

## ✅ Testing

Test the API using curl:

```bash
curl -X POST http://127.0.0.1:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"question": "What are the symptoms of diabetes?", "debug": false}'
```

Or visit `http://127.0.0.1:8000/docs` for interactive API testing.
