# MongoDB Setup Guide

## ✅ What's Been Added

1. **MongoDB Integration**: The API now stores user question/answer history in MongoDB
2. **History Endpoint**: New `/history/{user_id}` endpoint to retrieve last 5 questions
3. **Automatic History Tracking**: When `user_id` is provided in `/ask` requests, Q&A pairs are automatically saved

## 📦 Dependencies Installed

- `motor` - Async MongoDB driver for Python
- `pymongo` - MongoDB Python driver (dependency of motor)

## 🔧 Configuration

### 1. Local MongoDB Setup

If you're using local MongoDB, make sure it's running:

```bash
# macOS (with Homebrew)
brew services start mongodb-community

# Linux
sudo systemctl start mongod

# Or check if running
mongosh --eval "db.adminCommand('ping')"
```

The default connection string in `.env` is:

```
MONGODB_URL=mongodb://localhost:27017
```

### 2. MongoDB Atlas (Cloud) Setup

If you're using MongoDB Atlas:

1. Create a free cluster at https://www.mongodb.com/cloud/atlas
2. Get your connection string
3. Update `.env`:

```
MONGODB_URL=mongodb+srv://username:password@cluster.mongodb.net/database
```

Replace:

- `username` - Your MongoDB Atlas username
- `password` - Your MongoDB Atlas password
- `cluster` - Your cluster name
- `database` - Database name (optional, defaults to `medical_chatbot`)

## 📊 Database Structure

**Database:** `medical_chatbot`  
**Collection:** `qa_history`

**Document Schema:**

```json
{
  "_id": "ObjectId",
  "user_id": "string",
  "question": "string",
  "answer": "string",
  "intent": "string",
  "timestamp": "ISODate"
}
```

## 🔄 Automatic Cleanup

The system automatically keeps only the **last 5 questions** per user. When a 6th question is added, the oldest one is deleted.

## 🚀 Usage Examples

### Save Question with History

```bash
POST http://127.0.0.1:8000/ask
Content-Type: application/json

{
  "question": "What are the symptoms of diabetes?",
  "user_id": "user123",
  "debug": false
}
```

### Retrieve History

```bash
GET http://127.0.0.1:8000/history/user123
```

Response:

```json
{
  "user_id": "user123",
  "history": [
    {
      "question": "What are the symptoms of diabetes?",
      "answer": "Common symptoms include...",
      "intent": "symptoms",
      "timestamp": "2024-01-15T10:30:00.000000"
    }
  ]
}
```

## ⚠️ Important Notes

1. **Optional Feature**: If MongoDB is not available, the API continues to work normally. History features are simply disabled.

2. **User ID**: The `user_id` field is optional in the `/ask` endpoint. If not provided, the question won't be saved to history.

3. **No Authentication**: Currently, any `user_id` can access any user's history. Consider adding authentication in production.

4. **Connection Errors**: The API will print warnings if MongoDB connection fails but will continue operating.

## 🧪 Testing

Test the MongoDB connection:

```python
# In Python shell
from motor.motor_asyncio import AsyncIOMotorClient
import asyncio

async def test():
    client = AsyncIOMotorClient("mongodb://localhost:27017")
    await client.admin.command('ping')
    print("✅ MongoDB connected!")

asyncio.run(test())
```

## 🔐 Security Recommendations

For production:

1. Use MongoDB Atlas with IP whitelisting
2. Use strong passwords and rotate them regularly
3. Enable MongoDB authentication
4. Use environment variables for connection strings (already implemented)
5. Consider adding user authentication/authorization
