# Medical Chatbot API

A sophisticated medical question-answering system built with FastAPI that combines BioBERT for intent classification, semantic search with FAISS, and OpenAI GPT-4o-mini for natural language generation.

## 🎯 Features

- **Intent Classification**: Uses fine-tuned BioBERT model to classify medical questions into 7 categories (causes, definition, prevention, risks, symptoms, treatment, other)
- **Semantic Search**: Retrieves relevant medical information using sentence transformers and FAISS vector search
- **LLM Enhancement**: Rewrites retrieved answers using OpenAI GPT-4o-mini for clarity and coherence
- **Conversation History**: MongoDB-based storage of the last 5 questions per user
- **Source Citations**: Returns sources with citations for transparency
- **Debug Mode**: Optional debug information for development and troubleshooting
- **Interactive API Docs**: Auto-generated Swagger UI and ReDoc documentation

## 🏗️ Architecture

```
User Question
    ↓
BioBERT Intent Classification (7 intents)
    ↓
FAISS Vector Search (Intent-specific knowledge base)
    ↓
Retrieve Top-K Relevant Answers
    ↓
OpenAI GPT-4o-mini Rewriting
    ↓
Final Answer with Citations
```

### Technology Stack

- **Framework**: FastAPI
- **Intent Model**: BioBERT (Hugging Face Transformers)
- **Embeddings**: Sentence-BERT (`all-MiniLM-L6-v2`)
- **Vector Search**: FAISS
- **LLM**: OpenAI GPT-4o-mini
- **Database**: MongoDB (Motor async driver)
- **Knowledge Bases**: CSV files with intent-specific medical information

## 📋 Prerequisites

- Python 3.8+
- MongoDB (local or Atlas cloud)
- OpenAI API key
- **Trained BioBERT intent model** (⚠️ **REQUIRED** - must be trained and placed in `intent_model/biobert_weighted_intent_final/`)
- Knowledge base CSV files in `data/` directory:
  - `causes_kb.csv`
  - `definition_kb.csv`
  - `other_kb.csv`
  - `prevention_kb.csv`
  - `risks_kb.csv`
  - `symptoms_kb.csv`
  - `treatment_kb.csv`

## 🚀 Installation

> **⚠️ IMPORTANT**: Before running the API, you **must** train the BioBERT intent classification model and place it in the `intent_model/` folder. See step 5 below for detailed instructions.

1. **Clone the repository**

   ```bash
   git clone <repository-url>
   cd medical_chatbot_api
   ```

2. **Create a virtual environment**

   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**

   ```bash
   pip install fastapi uvicorn
   pip install torch transformers sentence-transformers
   pip install pandas faiss-cpu  # or faiss-gpu for GPU support
   pip install openai python-dotenv
   pip install motor pymongo
   ```

4. **Set up environment variables**

   Create a `.env` file in the root directory:

   ```env
   OPENAI_API_KEY=your_openai_api_key_here
   MONGODB_URL=mongodb://localhost:27017
   ```

   For MongoDB Atlas:

   ```env
   MONGODB_URL=mongodb+srv://username:password@cluster.mongodb.net/database
   ```

5. **Train and place the BioBERT intent model** ⚠️ **REQUIRED**

   **This is the most important step!** You must train the BioBERT model for intent classification and place it in the correct location.

   **Training Steps:**

   a. **Prepare your training data**

   Your training data should be a CSV or JSON file with medical questions labeled with one of the 7 intents:

   - `causes`, `definition`, `other`, `prevention`, `risks`, `symptoms`, `treatment`

   Example format:

   ```csv
   question,label
   "What are the symptoms of diabetes?","symptoms"
   "How to prevent heart disease?","prevention"
   "What causes high blood pressure?","causes"
   ```

   b. **Train the BioBERT model**

   Use the following Python script to fine-tune BioBERT for intent classification:

   ```python
   from transformers import (
       AutoTokenizer,
       AutoModelForSequenceClassification,
       TrainingArguments,
       Trainer
   )
   from datasets import load_dataset
   import torch

   # Load BioBERT base model
   # ⚠️ IMPORTANT: The label mapping MUST match exactly what's in app.py (lines 94-104)
   model_name = "dmis-lab/biobert-v1.1"
   tokenizer = AutoTokenizer.from_pretrained(model_name)
   model = AutoModelForSequenceClassification.from_pretrained(
       model_name,
       num_labels=7,  # 7 intent categories
       id2label={
           0: "causes",
           1: "definition",
           2: "other",
           3: "prevention",
           4: "risks",
           5: "symptoms",
           6: "treatment"
       },
       label2id={
           "causes": 0,
           "definition": 1,
           "other": 2,
           "prevention": 3,
           "risks": 4,
           "symptoms": 5,
           "treatment": 6
       }
   )

   # Load and preprocess your training data
   # dataset = load_dataset("csv", data_files="your_training_data.csv")
   # ... (implement data preprocessing and tokenization)

   # Training arguments
   training_args = TrainingArguments(
       output_dir="./intent_model/biobert_weighted_intent_final",
       num_train_epochs=3,
       per_device_train_batch_size=16,
       per_device_eval_batch_size=16,
       warmup_steps=500,
       weight_decay=0.01,
       logging_dir="./logs",
       evaluation_strategy="epoch",
       save_strategy="epoch",
       load_best_model_at_end=True,
   )

   # Trainer setup and training
   # trainer = Trainer(...)
   # trainer.train()

   # Save the final model
   model.save_pretrained("./intent_model/biobert_weighted_intent_final")
   tokenizer.save_pretrained("./intent_model/biobert_weighted_intent_final")
   ```

   c. **Alternative: Use pre-trained weights**

   If you have a pre-trained model or weights, ensure the directory structure is:

   ```
   intent_model/
   └── biobert_weighted_intent_final/
       ├── config.json
       ├── pytorch_model.bin (or model.safetensors)
       ├── tokenizer_config.json
       ├── vocab.txt
       └── ... (other tokenizer files)
   ```

   d. **Verify model placement**

   After training or placing the model, verify the structure:

   ```bash
   ls -la intent_model/biobert_weighted_intent_final/
   ```

   The directory should contain at minimum:

   - `config.json` - Model configuration
   - Model weights file (`pytorch_model.bin` or `model.safetensors`)
   - `tokenizer_config.json` - Tokenizer configuration
   - `vocab.txt` - Vocabulary file

   **⚠️ Critical**: Without a trained model in `intent_model/biobert_weighted_intent_final/`, the API **will not start** and will raise an error when trying to load the model.

6. **Ensure knowledge bases are present**

   Make sure all knowledge base CSV files are in the `data/` directory with an `answer` column.

## ▶️ Running the API

Start the FastAPI server:

```bash
uvicorn app:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at:

- API: `http://localhost:8000`
- Interactive docs (Swagger): `http://localhost:8000/docs`
- Alternative docs (ReDoc): `http://localhost:8000/redoc`

## 📡 API Endpoints

### `GET /`

Returns API information and available endpoints.

**Response:**

```json
{
  "message": "Medical Chatbot API",
  "version": "1.0",
  "endpoints": { ... }
}
```

### `POST /ask`

Ask a medical question and get an AI-generated answer.

**Request:**

```json
{
  "question": "What are the symptoms of diabetes?",
  "debug": false
}
```

**Response:**

```json
{
  "intent": "symptoms",
  "answer": "Common symptoms of diabetes include increased thirst, frequent urination, and fatigue. [1] [2]",
  "sources": [
    {
      "id": 1,
      "text": "Increased thirst and frequent urination are common early signs..."
    },
    {
      "id": 2,
      "text": "Other symptoms may include fatigue and blurred vision..."
    }
  ],
  "debug": null
}
```

### `GET /history`

Get the last 5 questions and answers (single-user mode).

**Response:**

```json
{
  "user_id": "default_user",
  "history": [
    {
      "question": "What are the symptoms of diabetes?",
      "answer": "Common symptoms include...",
      "intent": "symptoms",
      "timestamp": "2024-01-15T10:30:00.000000"
    }
  ]
}
```

## 📝 Intent Categories

The system classifies questions into 7 categories:

- `causes` - Questions about disease causes
- `definition` - Questions asking for definitions
- `other` - Miscellaneous questions
- `prevention` - Questions about prevention methods
- `risks` - Questions about risk factors
- `symptoms` - Questions about symptoms
- `treatment` - Questions about treatment options

## 💻 Usage Examples

### Python

```python
import requests

response = requests.post(
    "http://localhost:8000/ask",
    json={
        "question": "What are the symptoms of diabetes?",
        "debug": False
    }
)

data = response.json()
print(f"Intent: {data['intent']}")
print(f"Answer: {data['answer']}")
```

### cURL

```bash
curl -X POST "http://localhost:8000/ask" \
  -H "Content-Type: application/json" \
  -d '{
    "question": "What are the symptoms of diabetes?",
    "debug": false
  }'
```

### JavaScript/TypeScript

```typescript
const response = await fetch("http://localhost:8000/ask", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    question: "What are the symptoms of diabetes?",
    debug: false,
  }),
});

const data = await response.json();
console.log(data.intent, data.answer);
```

## 📁 Project Structure

```
medical_chatbot_api/
├── app.py                          # Main FastAPI application
├── data/                           # Knowledge base CSV files
│   ├── causes_kb.csv
│   ├── definition_kb.csv
│   ├── other_kb.csv
│   ├── prevention_kb.csv
│   ├── risks_kb.csv
│   ├── symptoms_kb.csv
│   └── treatment_kb.csv
├── intent_model/                   # Trained BioBERT model
│   └── biobert_weighted_intent_final/
├── .env                            # Environment variables (not in repo)
├── README.md                       # This file
├── API_STRUCTURE.md                # Detailed API documentation
├── FRONTEND_API_STRUCTURE.md       # Frontend integration guide
├── MOBILE_INTEGRATION_GUIDE.md     # Mobile app integration guide
├── MONGODB_SETUP.md                # MongoDB setup instructions
└── QUICK_REFERENCE.md              # Quick API reference
```

## 🔧 Configuration

### Environment Variables

| Variable         | Description                      | Required | Default                     |
| ---------------- | -------------------------------- | -------- | --------------------------- |
| `OPENAI_API_KEY` | OpenAI API key for LLM rewriting | Yes      | -                           |
| `MONGODB_URL`    | MongoDB connection string        | No       | `mongodb://localhost:27017` |

### Database Configuration

- **Database Name**: `medical_chatbot`
- **Collection**: `qa_history`
- **History Limit**: Last 5 questions per user

The API gracefully handles MongoDB connection failures and continues operating without history features.

## 🧪 Development

### Debug Mode

Enable debug mode to see detailed information about the processing pipeline:

```json
{
  "question": "What are the symptoms of diabetes?",
  "debug": true
}
```

This returns additional information:

- Predicted intent
- Raw retrieved answers
- LLM prompt
- Number of retrieved documents
- Knowledge base used

### Testing

Use the interactive API documentation at `http://localhost:8000/docs` to test endpoints directly.

## 📚 Additional Documentation

- **[API_STRUCTURE.md](API_STRUCTURE.md)** - Complete API schema and examples
- **[FRONTEND_API_STRUCTURE.md](FRONTEND_API_STRUCTURE.md)** - Frontend integration guide
- **[MOBILE_INTEGRATION_GUIDE.md](MOBILE_INTEGRATION_GUIDE.md)** - Mobile app integration (React Native, Flutter, etc.)
- **[MONGODB_SETUP.md](MONGODB_SETUP.md)** - MongoDB configuration guide
- **[QUICK_REFERENCE.md](QUICK_REFERENCE.md)** - Quick API reference

## ⚠️ Important Notes

1. **⚠️ Model Training is REQUIRED**: **You must train the BioBERT intent classification model before running the API.** The API will fail to start if the model is not present at `intent_model/biobert_weighted_intent_final/`. See the Installation section above for detailed training instructions.

2. **Single-User Mode**: The API is currently configured for single-user operation with a fixed user ID (`default_user`).

3. **MongoDB Optional**: The API works without MongoDB, but history features will be disabled.

4. **Model Requirements**: The trained BioBERT intent model must be present at the specified path (`intent_model/biobert_weighted_intent_final/`) for the API to start. The model directory must include `config.json`, model weights, and tokenizer files.

5. **Knowledge Bases**: All knowledge base CSV files must have an `answer` column for the system to function.

6. **API Costs**: This API uses OpenAI GPT-4o-mini, which incurs API costs. Monitor your usage.

## 🔐 Security Considerations

- Store API keys securely in `.env` file (never commit to version control)
- Use MongoDB Atlas with IP whitelisting for production
- Implement authentication/authorization for production use
- Validate and sanitize user inputs
- Consider rate limiting for production deployments

## 📄 License

[Add your license information here]

## 🤝 Contributing

[Add contribution guidelines here]

## 👤 Author

[Add author information here]

## 🙏 Acknowledgments

- BioBERT for medical text understanding
- OpenAI for LLM capabilities
- Hugging Face for transformer models
- FastAPI for the web framework
