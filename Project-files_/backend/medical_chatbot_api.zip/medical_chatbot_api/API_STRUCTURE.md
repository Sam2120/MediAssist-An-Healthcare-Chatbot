# Medical Chatbot API - Structure & Schema

## Base URL

```
http://127.0.0.1:8000
```

---

## Endpoints

### POST `/ask`

**Request:**

```json
{
  "question": "string (required)",
  "user_id": "string (optional) - User identifier for history tracking",
  "debug": "boolean (optional, default: false)"
}
```

**Response:**

```json
{
  "intent": "string",
  "answer": "string",
  "sources": [
    {
      "id": "number",
      "text": "string"
    }
  ],
  "debug": "object | null"
}
```

**Intent Values:**

- `causes`
- `definition`
- `other`
- `prevention`
- `risks`
- `symptoms`
- `treatment`

---

### GET `/history/{user_id}`

Get the last 5 questions and answers for a specific user.

**Path Parameter:**

- `user_id` (string, required) - User identifier

**Response:**

```json
{
  "user_id": "string",
  "history": [
    {
      "question": "string",
      "answer": "string",
      "intent": "string",
      "timestamp": "ISO 8601 datetime string"
    }
  ]
}
```

**Example Response:**

```json
{
  "user_id": "user123",
  "history": [
    {
      "question": "What are the symptoms of diabetes?",
      "answer": "Common symptoms include...",
      "intent": "symptoms",
      "timestamp": "2024-01-15T10:30:00.000000"
    }
  ]
}
```

---

## TypeScript Interfaces

```typescript
interface QuestionRequest {
  question: string;
  user_id?: string; // Optional - for history tracking
  debug?: boolean;
}

interface Source {
  id: number;
  text: string;
}

interface AnswerResponse {
  intent: string;
  answer: string;
  sources: Source[];
  debug?: {
    predicted_intent: string;
    retrieved_answers_raw: string[];
    llm_prompt: string;
    num_retrieved_docs: number;
    kb_used: string;
  } | null;
}

interface HistoryItem {
  question: string;
  answer: string;
  intent: string;
  timestamp: string; // ISO 8601 format
}

interface HistoryResponse {
  user_id: string;
  history: HistoryItem[];
}
```

---

## Example Request

```bash
POST http://127.0.0.1:8000/ask
Content-Type: application/json

{
  "question": "What are the symptoms of diabetes?",
  "user_id": "user123",
  "debug": false
}
```

```bash
GET http://127.0.0.1:8000/history/user123
```

## Example Response

```json
{
  "intent": "symptoms",
  "answer": "Common symptoms of diabetes include increased thirst, frequent urination, and fatigue. [1] [2]",
  "sources": [
    {
      "id": 1,
      "text": "Increased thirst and frequent urination are common early signs..."
    },
    {
      "id": 2,
      "text": "Other symptoms may include fatigue and blurred vision..."
    }
  ],
  "debug": null
}
```

---

## MongoDB Configuration

The API uses MongoDB to store user question/answer history. Configure the connection in your `.env` file:

```
MONGODB_URL=mongodb://localhost:27017
```

For MongoDB Atlas (cloud), use:

```
MONGODB_URL=mongodb+srv://username:password@cluster.mongodb.net/database
```

**Note:** The history feature automatically stores the last 5 questions per user. If MongoDB is not available, the API will continue to work but history will not be saved.
