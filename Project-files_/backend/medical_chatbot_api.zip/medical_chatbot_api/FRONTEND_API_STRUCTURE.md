# Medical Chatbot API - Frontend Integration Structure

## Base URL

```
http://127.0.0.1:8000
```

---

## Endpoints

### 1. POST `/ask`

Ask a medical question to the chatbot.

**Request:**

```json
{
  "question": "string (required)",
  "debug": "boolean (optional, default: false)"
}
```

**Response:**

```json
{
  "intent": "string",
  "answer": "string",
  "sources": [
    {
      "id": "number",
      "text": "string"
    }
  ],
  "debug": "object | null"
}
```

**Example Request:**

```bash
POST http://127.0.0.1:8000/ask
Content-Type: application/json

{
  "question": "What are the symptoms of diabetes?",
  "debug": false
}
```

**Example Response:**

```json
{
  "intent": "symptoms",
  "answer": "Common symptoms of diabetes include increased thirst, frequent urination, and fatigue. [1] [2]",
  "sources": [
    {
      "id": 1,
      "text": "Increased thirst and frequent urination are common early signs..."
    },
    {
      "id": 2,
      "text": "Other symptoms may include fatigue and blurred vision..."
    }
  ],
  "debug": null
}
```

---

### 2. GET `/history`

Get the last 5 questions and answers (single user app).

**Request:**

```
GET http://127.0.0.1:8000/history
```

**Response:**

```json
{
  "user_id": "default_user",
  "history": [
    {
      "question": "string",
      "answer": "string",
      "intent": "string",
      "timestamp": "ISO 8601 datetime string"
    }
  ]
}
```

**Example Response:**

```json
{
  "user_id": "default_user",
  "history": [
    {
      "question": "What are the symptoms of diabetes?",
      "answer": "Common symptoms include...",
      "intent": "symptoms",
      "timestamp": "2024-01-15T10:30:00.000000"
    },
    {
      "question": "What causes high blood pressure?",
      "answer": "High blood pressure can be caused by...",
      "intent": "causes",
      "timestamp": "2024-01-15T10:25:00.000000"
    }
  ]
}
```

---

## Intent Values

- `causes`
- `definition`
- `other`
- `prevention`
- `risks`
- `symptoms`
- `treatment`

---

## TypeScript Interfaces

```typescript
// Request
interface QuestionRequest {
  question: string;
  debug?: boolean;
}

// Response
interface Source {
  id: number;
  text: string;
}

interface AnswerResponse {
  intent: string;
  answer: string;
  sources: Source[];
  debug?: {
    predicted_intent: string;
    retrieved_answers_raw: string[];
    llm_prompt: string;
    num_retrieved_docs: number;
    kb_used: string;
  } | null;
}

// History
interface HistoryItem {
  question: string;
  answer: string;
  intent: string;
  timestamp: string; // ISO 8601 format
}

interface HistoryResponse {
  user_id: string;
  history: HistoryItem[];
}
```

---

## React Native Example

```typescript
// API Service
const API_BASE_URL = "http://127.0.0.1:8000"; // Change to production URL

export const askQuestion = async (
  question: string,
  debug: boolean = false
): Promise<AnswerResponse> => {
  const response = await fetch(`${API_BASE_URL}/ask`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      question,
      debug,
    }),
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  return await response.json();
};

export const getHistory = async (): Promise<HistoryResponse> => {
  const response = await fetch(`${API_BASE_URL}/history`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  });

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }

  return await response.json();
};

// Usage
const handleAskQuestion = async () => {
  try {
    const result = await askQuestion("What are the symptoms of diabetes?");
    console.log("Intent:", result.intent);
    console.log("Answer:", result.answer);
    console.log("Sources:", result.sources);
  } catch (error) {
    console.error("Error:", error);
  }
};

const handleGetHistory = async () => {
  try {
    const history = await getHistory();
    console.log("History:", history.history);
  } catch (error) {
    console.error("Error:", error);
  }
};
```

---

## Error Responses

### 422 Validation Error

```json
{
  "detail": [
    {
      "loc": ["body", "question"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

### 500 Server Error

```json
{
  "detail": "Internal server error"
}
```

---

## Notes

- **No user_id needed**: The app uses a fixed user ID (`default_user`) automatically
- **History**: Automatically saves last 5 questions per user
- **Sources**: Each answer includes source citations with IDs that match the `[1]`, `[2]` references in the answer text
- **Debug mode**: Set `debug: true` to get additional information about intent classification and retrieval
