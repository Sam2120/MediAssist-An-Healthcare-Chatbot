# ============================================
# app.py — Medical Chatbot Backend (FastAPI)
# ============================================

import os
import torch
import pandas as pd
import faiss
import uuid
from datetime import datetime
from typing import Optional
from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId

# Load environment variables from .env file
load_dotenv()

from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification
)

from sentence_transformers import SentenceTransformer
from openai import OpenAI

# ============================================
# 1️⃣ FastAPI app
# ============================================

app = FastAPI(
    title="Medical Chatbot API",
    description="BioBERT + Retrieval + LLM Rewriting",
    version="1.0"
)

# ============================================
# 2️⃣ Load OpenAI client (once)
# ============================================

# client = OpenAI(api_key=os.getenv("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"))

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# ============================================
# 2️⃣ MongoDB Setup
# ============================================

MONGODB_URL = os.getenv("MONGODB_URL", "mongodb://localhost:27017")
DATABASE_NAME = "medical_chatbot"
COLLECTION_NAME = "qa_history"

# Fixed user ID for single-user app
FIXED_USER_ID = "default_user"

# Initialize MongoDB client
mongodb_client: Optional[AsyncIOMotorClient] = None
database = None

async def connect_to_mongo():
    """Connect to MongoDB"""
    global mongodb_client, database
    try:
        mongodb_client = AsyncIOMotorClient(MONGODB_URL)
        database = mongodb_client[DATABASE_NAME]
        # Test connection
        await mongodb_client.admin.command('ping')
        print("✅ Connected to MongoDB")
    except Exception as e:
        print(f"⚠️ MongoDB connection error: {e}")
        print("⚠️ Continuing without database (history feature disabled)")

async def close_mongo_connection():
    """Close MongoDB connection"""
    global mongodb_client
    if mongodb_client:
        mongodb_client.close()
        print("✅ MongoDB connection closed")

@app.on_event("startup")
async def startup_event():
    await connect_to_mongo()

@app.on_event("shutdown")
async def shutdown_event():
    await close_mongo_connection()

# ============================================
# 3️⃣ Label mapping (must match training)
# ============================================

LABELS = [
    "causes",
    "definition",
    "other",
    "prevention",
    "risks",
    "symptoms",
    "treatment"
]

id2label = {i: l for i, l in enumerate(LABELS)}

# ============================================
# 4️⃣ Load BioBERT intent classifier (ONCE)
# ============================================

print("🔹 Loading BioBERT intent model...")

INTENT_MODEL_PATH = "intent_model/biobert_weighted_intent_final"

intent_tokenizer = AutoTokenizer.from_pretrained(INTENT_MODEL_PATH)
intent_model = AutoModelForSequenceClassification.from_pretrained(
    INTENT_MODEL_PATH
)

intent_model.eval()

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
intent_model.to(DEVICE)

print("✅ BioBERT loaded on", DEVICE)

# ============================================
# 5️⃣ Load Sentence-BERT (ONCE)
# ============================================

print("🔹 Loading sentence embedding model...")
embedder = SentenceTransformer("all-MiniLM-L6-v2")
print("✅ Embedder loaded")

# ============================================
# 6️⃣ Load intent-specific knowledge bases (ONCE)
# ============================================

KB_DIR = "data"

kb_store = {}   # intent → {df, embeddings, faiss_index}

for intent in LABELS:
    path = f"{KB_DIR}/{intent}_kb.csv"

    if not os.path.exists(path):
        print(f"⚠️ Missing KB for intent: {intent}")
        continue

    df = pd.read_csv(path)

    texts = df["answer"].astype(str).tolist()
    embeddings = embedder.encode(texts, convert_to_numpy=True)

    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(embeddings)

    kb_store[intent] = {
        "df": df,
        "embeddings": embeddings,
        "index": index
    }

    print(f"✅ Loaded KB for intent: {intent} ({len(df)} rows)")

# ============================================
# 7️⃣ Request / Response Schemas
# ============================================

class QuestionRequest(BaseModel):
    question: str
    # user_id: Optional[str] = None  # User identifier for history tracking (commented for single user)
    debug: bool = False

class AnswerResponse(BaseModel):
    intent: str
    answer: str
    sources: list
    debug: Optional[dict] = None

class HistoryItem(BaseModel):
    question: str
    answer: str
    intent: str
    timestamp: str

class HistoryResponse(BaseModel):
    user_id: str
    history: list[HistoryItem]

# ============================================
# 8️⃣ Helper Functions
# ============================================

def predict_intent(question: str) -> str:
    inputs = intent_tokenizer(
        question,
        return_tensors="pt",
        truncation=True,
        max_length=128
    ).to(DEVICE)

    with torch.no_grad():
        logits = intent_model(**inputs).logits
        pred_id = torch.argmax(logits, dim=1).item()

    return id2label[pred_id]


def retrieve_answers(intent: str, question: str, top_k: int = 3):
    if intent not in kb_store:
        return []

    q_emb = embedder.encode([question], convert_to_numpy=True)
    D, I = kb_store[intent]["index"].search(q_emb, top_k)

    df = kb_store[intent]["df"]
    results = []

    for idx in I[0]:
        results.append(df.iloc[idx]["answer"])

    return results


def build_llm_prompt(question, intent, retrieved_answers):
    citations = []
    context = ""

    for i, ans in enumerate(retrieved_answers, 1):
        context += f"[{i}] {ans}\n\n"
        citations.append({"id": i, "text": ans})

    prompt = f"""
You are a medical assistant.

Answer the user's question using ONLY the information provided below.
DO NOT add new medical facts.
Rephrase clearly and concisely.

Question:
{question}

Medical Context:
{context}

Answer with citations like [1], [2].
"""

    return prompt, citations


def rewrite_with_llm(prompt):
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )

    return response.choices[0].message.content.strip()

# ============================================
# 8️⃣ Database Helper Functions
# ============================================

async def save_qa_to_db(user_id: str, question: str, answer: str, intent: str):
    """Save question and answer to MongoDB"""
    if database is None:
        return
    
    try:
        qa_doc = {
            "user_id": user_id,
            "question": question,
            "answer": answer,
            "intent": intent,
            "timestamp": datetime.utcnow()
        }
        await database[COLLECTION_NAME].insert_one(qa_doc)
        
        # Keep only last 5 questions per user
        # Delete older questions
        user_history = await database[COLLECTION_NAME].find(
            {"user_id": user_id}
        ).sort("timestamp", -1).to_list(length=6)
        
        if len(user_history) > 5:
            # Delete the oldest ones beyond 5
            for doc in user_history[5:]:
                await database[COLLECTION_NAME].delete_one({"_id": doc["_id"]})
                
    except Exception as e:
        print(f"⚠️ Error saving to database: {e}")

async def get_user_history(user_id: str, limit: int = 5):
    """Get last N questions and answers for a user"""
    if database is None:
        return []
    
    try:
        cursor = database[COLLECTION_NAME].find(
            {"user_id": user_id}
        ).sort("timestamp", -1).limit(limit)
        
        history = []
        async for doc in cursor:
            history.append({
                "question": doc["question"],
                "answer": doc["answer"],
                "intent": doc["intent"],
                "timestamp": doc["timestamp"].isoformat()
            })
        
        return history
    except Exception as e:
        print(f"⚠️ Error retrieving history: {e}")
        return []

# ============================================
# 9️⃣ API Endpoints
# ============================================

@app.get("/")
def root():
    """Root endpoint with API information"""
    return {
        "message": "Medical Chatbot API",
        "version": "1.0",
        "endpoints": {
            "/ask": "POST - Ask a medical question",
            "/history": "GET - Get last 5 questions and answers (single user)",
            "/docs": "GET - Interactive API documentation (Swagger UI)",
            "/redoc": "GET - Alternative API documentation (ReDoc)"
        },
        "usage": {
            "endpoint": "/ask",
            "method": "POST",
            "body": {
                "question": "string (required)",
                "debug": "boolean (optional, default: false)"
            }
        }
    }

@app.post("/ask", response_model=AnswerResponse)
async def ask_medical_question(req: QuestionRequest):

    # 1️⃣ Intent classification
    intent = predict_intent(req.question)

    # 2️⃣ Retrieval
    retrieved = retrieve_answers(intent, req.question)

    if not retrieved:
        response_data = {
            "intent": intent,
            "answer": "No reliable information found.",
            "sources": [],
            "debug": {} if req.debug else None
        }
        
        # Save to database with fixed user ID
        if database is not None:
            await save_qa_to_db(
                FIXED_USER_ID,
                req.question,
                response_data["answer"],
                intent
            )
        
        return response_data

    # 3️⃣ Build prompt
    prompt, citations = build_llm_prompt(
        req.question,
        intent,
        retrieved
    )

    # 4️⃣ LLM rewrite
    final_answer = rewrite_with_llm(prompt)

    # 5️⃣ Debug payload (ONLY if debug=True)
    debug_payload = None
    if req.debug:
        debug_payload = {
            "predicted_intent": intent,
            "retrieved_answers_raw": retrieved,
            "llm_prompt": prompt,
            "num_retrieved_docs": len(retrieved),
            "kb_used": f"{intent}_kb.csv"
        }

    response_data = {
        "intent": intent,
        "answer": final_answer,
        "sources": citations,
        "debug": debug_payload
    }
    
    # 6️⃣ Save to database with fixed user ID
    if database is not None:
        await save_qa_to_db(
            FIXED_USER_ID,
            req.question,
            final_answer,
            intent
        )

    return response_data

@app.get("/history", response_model=HistoryResponse)
async def get_history():
    """Get last 5 questions and answers (single user app)"""
    history = await get_user_history(FIXED_USER_ID, limit=5)
    
    return {
        "user_id": FIXED_USER_ID,
        "history": history
    }

# @app.post("/user/register")
# async def register_user():
#     """Generate and return a new user ID - COMMENTED: Using fixed user ID for single-user app"""
#     user_id = str(uuid.uuid4())
#     return {
#         "user_id": user_id,
#         "message": "User ID generated successfully. Use this ID in your requests."
#     }


# ============================================
# ✅ END OF FILE
# ============================================
