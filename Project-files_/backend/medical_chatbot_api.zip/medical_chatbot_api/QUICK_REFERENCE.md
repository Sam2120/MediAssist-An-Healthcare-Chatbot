# Quick Reference - Medical Chatbot API

## API Endpoint

```
POST http://127.0.0.1:8000/ask
```

## Request

```json
{
  "question": "What are the symptoms of diabetes?",
  "debug": false
}
```

## Response

```json
{
  "intent": "symptoms",
  "answer": "Answer text with citations [1], [2]...",
  "sources": [
    { "id": 1, "text": "Source text 1" },
    { "id": 2, "text": "Source text 2" }
  ]
}
```

## Intents

- causes, definition, other, prevention, risks, symptoms, treatment

## React Native Example

```typescript
const response = await fetch("http://127.0.0.1:8000/ask", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ question: "Your question here" }),
});
const data = await response.json();
```

## Swift Example

```swift
let requestBody = QuestionRequest(question: "Your question", debug: false)
let request = URLRequest(url: URL(string: "http://127.0.0.1:8000/ask")!)
request.httpMethod = "POST"
request.setValue("application/json", forHTTPHeaderField: "Content-Type")
request.httpBody = try JSONEncoder().encode(requestBody)
```

## Kotlin Example

```kotlin
@POST("ask")
suspend fun askQuestion(@Body request: QuestionRequest): AnswerResponse
```

## Flutter Example

```dart
final response = await http.post(
  Uri.parse('http://127.0.0.1:8000/ask'),
  headers: {'Content-Type': 'application/json'},
  body: jsonEncode({'question': 'Your question'}),
);
```
